%% LETDOWN VESSEL ADIABATIC FLASH CALCULATION FOR NH3/N2/H2 SYSTEM
function letdown_vessel_flash_adiabatic_corrected()

% --- INPUT PARAMETERS ---
comp = {'NH3','N2','H2'};
z = [0.718 0.270 0.012];     % Feed mole fractions
T_in = 373.15;               % Inlet temperature [K] 
P_in = 100;                  % Inlet pressure [bar]
P_out = 20;                  % Outlet pressure [bar]

% Physical properties
% CpV: Vapor heat capacity [J/mol/K]
CpV = [35.6 29.1 28.8];      
% CpL: Liquid heat capacity [J/mol/K] (Only NH3 is truly liquid here)
CpL_NH3 = 80.8;      

% Antoine constants for NH3 ONLY (log10(Psat_mmHg) = A - B/(C + T_celsius))
A_nh3 = 7.55466; B_nh3 = 1002.711; C_nh3 = 247.885;   

% Heat of vaporization at 298K [J/mol] - Only needed for NH3
Hvap_NH3_298 = 23350; 

% --- CORRECTION 1: ENTHALPY FUNCTIONS ---
% We define Enthalpy = 0 for Liquid at 298K for condensables, 
% and Ideal Gas at 298K for non-condensables.

% Enthalpy of Liquid Phase (Mix of Liquid NH3 and Dissolved Gases)
% Note: We approximate dissolved gas enthalpy as gas enthalpy (Ideal Solution)
hL = @(x, T) x(1) * CpL_NH3 * (T - 298) + ...         % NH3 (Liquid)
             x(2) * CpV(2) * (T - 298) + ...          % N2 (Dissolved Gas)
             x(3) * CpV(3) * (T - 298);               % H2 (Dissolved Gas)

% Enthalpy of Vapor Phase
hV = @(y, T) y(1) * (CpV(1)*(T-298) + Hvap_NH3_298) + ... % NH3 (Vapor)
             y(2) * CpV(2)*(T-298) + ...                  % N2 (Gas)
             y(3) * CpV(3)*(T-298);                       % H2 (Gas)

% Calculate Feed Enthalpy (Assuming Feed is High Pressure Liquid/Dissolved Mix)
h_feed = hL(z, T_in);

fprintf('\n=== LETDOWN VESSEL ADIABATIC FLASH (CORRECTED) ===\n');
fprintf('Feed Enthalpy calculated: %.2f J/mol\n', h_feed);

% --- TEMPERATURE SEARCH FOR ADIABATIC FLASH ---
T_low = 200;     
T_high = T_in;   

options = optimset('Display','off','TolX',1e-6);
try
    % Solve for T where (h_feed - h_outlet) = 0
    T_out = fzero(@(T) energy_residual_T(T, P_out, z, h_feed, hL, hV, A_nh3, B_nh3, C_nh3), ...
                  [T_low T_high], options);
    fprintf('Converged outlet temperature: %.4f K (%.1f°C)\n', T_out, T_out-273.15);
catch ME
    fprintf('Error in temperature solver: %s\n', ME.message);
    return;
end

% --- CALCULATE FINAL FLASH RESULTS ---
[x, y, V] = flash_at_TP(T_out, P_out, z, A_nh3, B_nh3, C_nh3);
h_liquid = hL(x, T_out);
h_vapor = hV(y, T_out);
h_outlet = (1-V)*h_liquid + V*h_vapor;
delta_T = T_in - T_out;

% --- DISPLAY RESULTS ---
fprintf('\n=== FINAL RESULTS ===\n');
fprintf('Inlet T: %.1f K, Out T: %.1f K, Drop: %.1f K\n', T_in, T_out, delta_T);
fprintf('Vapor fraction (V/F): %.4f\n', V);
fprintf('Liquid fraction:      %.4f\n', 1-V);

fprintf('\nComponent Analysis:\n');
fprintf('%-5s %-9s %-9s %-9s %-9s\n', 'Comp', 'z_feed', 'x_liq', 'y_vap', 'K-value');
fprintf('--------------------------------------------------\n');
K_vals = y./(x+1e-10);
for i = 1:3
    fprintf('%-5s %.4f    %.4f    %.4f    %.2f\n', comp{i}, z(i), x(i), y(i), K_vals(i));
end

% Verification
err = abs(h_feed - h_outlet);
fprintf('\nEnergy Balance Error: %.4f J/mol\n', err);

end

%% --- SUPPORTING FUNCTIONS ---

function res = energy_residual_T(T, P, z, h_feed, hL, hV, A, B, C)
    [x, y, V] = flash_at_TP(T, P, z, A, B, C);
    if V < 0 || V > 1, res = 1e6; return; end
    h_out = (1-V)*hL(x, T) + V*hV(y, T);
    res = h_feed - h_out;
end

function [x, y, V] = flash_at_TP(T, P, z, A, B, C)
    % 1. Calculate K for Ammonia using Antoine (Raoult's Law)
    T_C = T - 273.15;
    Psat_NH3 = 10^(A - B / (C + T_C)); % mmHg
    Psat_NH3_bar = Psat_NH3 * 0.00133322; 
    K_NH3 = Psat_NH3_bar / P;

    % 2. CORRECTION: Use Approximate Henry's Constants for N2 and H2
    % These are rough approximations for N2/H2 in Liquid Ammonia
    % H_const is in bar. K = H / P
    % H_N2 ~ 3000 bar (very volatile)
    % H_H2 ~ 8000 bar (extremely volatile)
    H_N2 = 3000; 
    H_H2 = 8000;
    
    K_N2 = H_N2 / P;
    K_H2 = H_H2 / P;
    
    K = [K_NH3, K_N2, K_H2];

    % Rachford-Rice Solver
    RR = @(V) sum(z .* (K - 1) ./ (1 + V.*(K - 1)));
    
    % Check boundaries
    if RR(1e-9) > 0 && RR(1-1e-9) > 0, V=1; 
    elseif RR(1e-9) < 0 && RR(1-1e-9) < 0, V=0;
    else
        try
            V = fzero(RR, [0 1]);
        catch
            V = 0.5; % Fallback
        end
    end
    
    % Calculate compositions
    x = z ./ (1 + V.*(K - 1));
    y = K .* x;
    
    % Normalize (fixes numerical drift)
    x = x / sum(x);
    y = y / sum(y);
end