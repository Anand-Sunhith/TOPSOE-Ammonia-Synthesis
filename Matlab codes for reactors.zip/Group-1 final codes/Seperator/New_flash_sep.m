%% SEPARATOR ADIABATIC FLASH (Two-Phase Force)
% Goal: Find Outlet Temperature and Vapor Fraction (V) where Energy Balance = 0
function separator_force_two_phase()

% --- 1. INPUT CONDITIONS (Modified for Condensation) ---
comp = {'N2','H2','O2','CO2','CO','H2O','CH4'};
z = [0.288 0.512 0.062 0.118 0.00025 0.144 0.000065]; 

% MODIFIED: Lower Temp and Higher Pressure to force Liquid Water
T_feed = 313.15;  % 40°C (Simulating a cooler upstream)
P = 50;           % 50 bar (High pressure forces condensation)

% --- 2. PHYSICAL PROPERTIES ---
% Cp Vapor [J/mol/K] (Approximate averages)
CpV = [29.1 28.8 29.4 37.0 29.1 34.0 35.0]; 

% Cp Liquid [J/mol/K] (Only Water exists as liquid here)
CpL_H2O = 75.3;   

% Antoine Constants (Water Only) - log10(P_mmHg)
A_H2O = 8.07131; B_H2O = 1730.63; C_H2O = 233.426;

% Latent Heat of Vaporization (Water) @ 298K [J/mol]
% This is the energy RELEASED when gas turns to liquid
Hvap_H2O = 40650; 

% --- 3. ENTHALPY FUNCTIONS ---
% Reference State: Ideal Gas at 298.15 K = 0 J/mol

% Feed Enthalpy (Assume Feed enters as Mixed Phase or Vapor, calculated rigorously)
% We calculate Feed Enthalpy based on T_feed. 
% To keep it simple/robust: We calculate Feed Enthalpy assuming it is 
% entering as a "potential" vapor, and the solver handles the phase change energy.
h_feed = sum(z .* CpV .* (T_feed - 298.15));

% Vapor Enthalpy (Cp * DeltaT)
hV = @(y, T) sum(y .* CpV .* (T - 298.15));

% Liquid Enthalpy (Cp_liq * DeltaT - Latent Heat)
% Note: The -Hvap term is crucial. It represents the energy drop from Gas to Liquid.
hL = @(x, T) x(6) * (CpL_H2O * (T - 298.15) - Hvap_H2O); 

fprintf('\n=== ADIABATIC SEPARATOR SIMULATION ===\n');
fprintf('Feed Conditions: %.1f K (%.1f C), %.1f bar\n', T_feed, T_feed-273.15, P);

% --- 4. SOLVER ---
% We search for the Outlet Temperature where Heat In = Heat Out
% The Temperature will RISE because Condensation is Exothermic (Releases Heat)
T_guess_low = T_feed; 
T_guess_high = T_feed + 100; % Allow for temperature rise

options = optimset('Display','off', 'TolX', 1e-4);

try
    T_out = fzero(@(T) energy_residual(T, z, P, h_feed, hL, hV, A_H2O, B_H2O, C_H2O), ...
                  [T_guess_low T_guess_high], options);
catch ME
    fprintf('Error: Solver failed to converge. The system might be all-vapor or all-liquid.\n');
    fprintf('Message: %s\n', ME.message);
    return;
end

% --- 5. FINAL CALCULATION AT CONVERGED TEMP ---
[x, y, V] = flash_at_T(T_out, z, P, A_H2O, B_H2O, C_H2O);
h_out = (1-V)*hL(x, T_out) + V*hV(y, T_out);

% --- 6. DISPLAY RESULTS ---
fprintf('\n=== FINAL RESULTS ===\n');
fprintf('Outlet Temperature:   %.2f K (%.2f °C)\n', T_out, T_out-273.15);
fprintf('Temperature Rise:     +%.2f K (Due to Heat of Condensation)\n', T_out - T_feed);
fprintf('Vapor Fraction (V):   %.4f\n', V);
fprintf('Liquid Fraction (L):  %.4f\n', 1-V);
fprintf('Energy Balance Error: %.4f J/mol\n', abs(h_feed - h_out));

fprintf('\nComponent Analysis:\n');
fprintf('%-6s %-9s %-9s %-9s %-9s\n', 'Comp', 'Feed(z)', 'Liq(x)', 'Vap(y)', 'K-value');
fprintf('--------------------------------------------------\n');
K_vals = y ./ (x + 1e-10);
for i = 1:length(comp)
    fprintf('%-6s %.4f    %.4f    %.4f    %.2f\n', comp{i}, z(i), x(i), y(i), K_vals(i));
end

% --- INTERPRETATION ---
fprintf('\n=== PHYSICAL INTERPRETATION ===\n');
fprintf('1. Feed entered at 40C. Water condensed.\n');
fprintf('2. Condensation released latent heat.\n');
fprintf('3. This heat warmed the vessel to %.1f C.\n', T_out-273.15);
fprintf('4. Equilibrium reached with %.1f%% liquid recovery.\n', (1-V)*100);

end

%% --- SUPPORTING FUNCTIONS ---

function res = energy_residual(T, z, P, hF, hL, hV, A, B, C)
    % 1. Perform VLE Flash at guessed T
    [x, y, V] = flash_at_T(T, z, P, A, B, C);
    
    % 2. Calculate Enthalpies
    h_liquid_val = hL(x, T);
    h_vapor_val = hV(y, T);
    
    % 3. Calculate Total Outlet Enthalpy
    h_outlet = (1-V)*h_liquid_val + V*h_vapor_val;
    
    % 4. Residual = In - Out (Should be 0)
    res = hF - h_outlet;
end

function [x, y, V] = flash_at_T(T, z, P, A, B, C)
    % 1. Calculate K-value for Water (Raoult's Law)
    T_C = T - 273.15;
    Psat_H2O = 10^(A - B / (T_C + C)) * 0.0133322; % Convert mmHg to bar
    K_H2O = Psat_H2O / P;
    
    % 2. Assign K-values
    % Non-condensables (N2, H2, CO2) get High K (e.g., 1000)
    % Water gets calculated K
    K = ones(size(z)) * 1000; 
    K(6) = K_H2O; % Water is at index 6
    
    % 3. Rachford-Rice Solver for V
    RR = @(v) sum(z .* (K - 1) ./ (1 + v .* (K - 1)));
    
    % Check boundaries first
    f0 = RR(1e-9);
    f1 = RR(1-1e-9);
    
    if f0 > 0 && f1 > 0
        V = 1; % All Vapor
    elseif f0 < 0 && f1 < 0
        V = 0; % All Liquid
    else
        % Solve for V between 0 and 1
        try
            V = fzero(RR, [1e-9 1-1e-9]);
        catch
            V = 1; % Default to vapor if solver struggles
        end
    end
    
    % 4. Calculate Compositions
    x = z ./ (1 + V .* (K - 1));
    y = K .* x;
    
    % Normalize to fix numerical drift
    x = x / sum(x);
    y = y / sum(y);
end