clear; clc; close all;

%% 1.0 COMPONENT PROPERTIES DEFINITION
% Define properties for each component in the gas mixture
components.N2.name = 'Nitrogen';
components.N2.M = 28.013;      % Molar Mass (kg/kmol)
components.N2.Tc = 126.2;      % Critical Temperature (K)
components.N2.Pc = 33.9;       % Critical Pressure (bar)
components.N2.Cp_coeffs = [28.90, -0.1571e-3, 0.8081e-6, -2.873e-9]; % Cp coeffs for kJ/kmol-K

components.CH4.name = 'Methane';
components.CH4.M = 16.043;
components.CH4.Tc = 190.6;
components.CH4.Pc = 46.0;
components.CH4.Cp_coeffs = [19.89, 75.36e-3, -28.90e-6, 74.90e-9];

components.Ar.name = 'Argon';
components.Ar.M = 39.948;
components.Ar.Tc = 151.0;
components.Ar.Pc = 48.6;
components.Ar.Cp_coeffs = [20.786, 0, 0, 0]; % Cp is constant for monatomic gas

% Universal Gas Constant
Ru = 8.314; % kJ/kmol-K

%% 2.0 INPUTS AND OPERATING CONDITIONS
% --- FIX: Define the mole fractions (y) as a structure ---
% The sum of mole fractions should be 1.0
y.N2 = 0.70;  % Example: 70% Nitrogen
y.CH4 = 0.20; % Example: 20% Methane
y.Ar = 0.10;  % Example: 10% Argon

% --- FIX: Define other missing process variables ---
P1 = 2;      % Inlet pressure (bar)
P2 = 10;      % Outlet pressure (bar)
eta_s = 0.85; % Isentropic efficiency

% Iteration Control
tolerance = 1e-4;      % Convergence tolerance for temperature (K)
max_iterations = 20;   % Maximum number of iterations to prevent infinite loops

%% 3.0 PRE-CALCULATIONS (CONSTANT MIXTURE PROPERTIES)

% Convert inlet temperature to Kelvin
T1_K = -28 + 273.15;

% Get field names for components
gas_names = fieldnames(y); % This will now work correctly

% --- Calculate Mixture Molar Mass (M_mix) ---
M_mix = 0;
for i = 1:length(gas_names)
    gas = gas_names{i};
    M_mix = M_mix + y.(gas) * components.(gas).M;
end

% --- Calculate Pseudo-Critical Properties using Kay's Rule ---
T_pc = 0; % Pseudo-critical temperature (K)
P_pc = 0; % Pseudo-critical pressure (bar)
for i = 1:length(gas_names)
    gas = gas_names{i};
    T_pc = T_pc + y.(gas) * components.(gas).Tc;
    P_pc = P_pc + y.(gas) * components.(gas).Pc;
end

%% 4.0 INITIAL GUESS FOR ITERATION (IDEAL GAS ASSUMPTION)
% This provides a starting point for the iterative calculation loop.

% Calculate mixture properties at inlet temperature T1
[~, ~, k_mix_initial] = calculate_mixture_properties(T1_K, components, y, Ru);

% Calculate initial estimate of isentropic discharge temperature (T2s)
% Eq: T2s/T1 = (P2/P1)^((k-1)/k)
T2s_est_ideal = T1_K * (P2 / P1)^((k_mix_initial - 1) / k_mix_initial);

% Calculate initial guess for actual discharge temperature (T2a)
% Eq: T2a = T1 + (T2s - T1) / eta_s
T2a_guess = T1_K + (T2s_est_ideal - T1_K) / eta_s;

fprintf('--- Starting Iterative Calculation ---\n');
fprintf('Initial Guess (Ideal Gas): T2a = %.2f K (%.2f °C)\n\n', T2a_guess, T2a_guess - 273.15);

%% 5.0 ITERATIVE CALCULATION FOR ACTUAL DISCHARGE TEMPERATURE (T2a)
% This loop refines the discharge temperature by recalculating gas properties
% at the average temperature of the compression path until convergence.

iteration = 0;
error = inf;
T2a_current = T2a_guess;
history = []; % Initialize as an empty array/matrix to store results of each iteration

while error > tolerance && iteration < max_iterations
    iteration = iteration + 1;
    T2a_prev = T2a_current;

    % a. Define Average Process Temperature
    T_avg = (T1_K + T2a_prev) / 2;

    % b. Calculate Average Gas Properties (k_mix_avg) at T_avg
    [~, ~, k_mix_avg] = calculate_mixture_properties(T_avg, components, y, Ru);

    % c. Recalculate Isentropic Discharge Temperature (T2s) using average k
    T2s_recalc = T1_K * (P2 / P1)^((k_mix_avg - 1) / k_mix_avg);

    % d. Recalculate Actual Discharge Temperature (T2a)
    T2a_current = T1_K + (T2s_recalc - T1_K) / eta_s;

    % e. Check for Convergence
    error = abs(T2a_current - T2a_prev);
    
    % Store and display iteration results
    history(iteration, :) = [iteration, T2a_prev, T_avg, k_mix_avg, T2s_recalc, T2a_current, error];
end

% Display Iteration Table
fprintf('Iter | T2a_guess (K) | T_avg (K) | k_mix_avg | T2s_recalc (K) | T2a_recalc (K) | Error (K)\n');
fprintf('--------------------------------------------------------------------------------------------\n');
for i = 1:size(history, 1)
    fprintf('%4d | %13.2f | %9.2f | %9.4f | %14.2f | %14.2f | %9.4f\n', history(i,:));
end
fprintf('--------------------------------------------------------------------------------------------\n');


%% 6.0 FINAL RESULTS AND COMPRESSOR WORK

fprintf('\n--- Calculation Converged ---\n');
if iteration >= max_iterations
    fprintf('Warning: Maximum number of iterations reached.\n');
end

T2a_final_K = T2a_current;
T2a_final_C = T2a_final_K - 273.15;

fprintf('Final Discharge Temperature (T2a): %.2f K (%.2f °C)\n', T2a_final_K, T2a_final_C);

% --- Calculate Specific Work of Compression (w_actual) ---
% Use the final converged average temperature to get the most accurate Cp
T_avg_final = (T1_K + T2a_final_K) / 2;
[~, Cp_mix_molar_avg, ~] = calculate_mixture_properties(T_avg_final, components, y, Ru);

% Convert molar Cp to mass-based cp (kJ/kg-K)
cp_mix_mass_avg = Cp_mix_molar_avg / M_mix;

% Calculate actual work using enthalpy change approximation: w = cp * deltaT
w_actual = cp_mix_mass_avg * (T2a_final_K - T1_K);

fprintf('Specific Work of Compression (w_actual): %.2f kJ/kg\n', w_actual);

% --- Real Gas Deviation Analysis (for context) ---
% Calculate Z at inlet and final outlet conditions
Tr1 = T1_K / T_pc;
Pr1 = P1 / P_pc;
Z1 = get_compressibility_Z(Tr1, Pr1);

Tr2 = T2a_final_K / T_pc;
Pr2 = P2 / P_pc;
Z2 = get_compressibility_Z(Tr2, Pr2);

fprintf('\n--- Real Gas Analysis ---\n');
fprintf('Inlet Compressibility Factor (Z1) at %.1f K, %.1f bar: %.4f\n', T1_K, P1, Z1);
fprintf('Outlet Compressibility Factor (Z2) at %.1f K, %.1f bar: %.4f\n', T2a_final_K, P2, Z2);
fprintf('Average Compressibility Factor (Z_avg): %.4f\n', (Z1+Z2)/2);


%% 7.0 LOCAL FUNCTIONS

function [M_mix, Cp_mix_molar, k_mix] = calculate_mixture_properties(T, components, y, Ru)
    % Calculates mixture properties for a given temperature.
    gas_names = fieldnames(y);
    
    % --- Mixture Molar Mass ---
    M_mix = 0;
    for i = 1:length(gas_names)
        gas = gas_names{i};
        M_mix = M_mix + y.(gas) * components.(gas).M;
    end
    
    % --- Mixture Molar Specific Heat (Cp_mix_molar) ---
    Cp_mix_molar = 0;
    for i = 1:length(gas_names)
        gas = gas_names{i};
        C = components.(gas).Cp_coeffs;
        % Cp(T) = A + BT + CT^2 + D*T^3 (in kJ/kmol-K)
        Cp_i = C(1) + C(2)*T + C(3)*T^2 + C(4)*T^3;
        Cp_mix_molar = Cp_mix_molar + y.(gas) * Cp_i;
    end
    
    % --- Mixture Specific Heat Ratio (k_mix) ---
    % Using Mayer's relation: Cv = Cp - R
    Cv_mix_molar = Cp_mix_molar - Ru;
    k_mix = Cp_mix_molar / Cv_mix_molar;
end


function Z = get_compressibility_Z(Tr, Pr)
    % Calculates the compressibility factor Z using the Van der Waals
    % equation of state in its cubic form.
    A = (27 * Pr) / (64 * Tr^2);
    B = Pr / (8 * Tr);
    
    % --- FIX: Define the coefficients for the cubic polynomial in Z ---
    % Z^3 - (1 + B)Z^2 + AZ - AB = 0
    coeffs = [1, -(1 + B), A, -A*B];
    
    % Find the roots of the cubic polynomial
    r = roots(coeffs);
    
    % Filter for real roots and select the largest one for the gas phase.
    real_roots = r(imag(r) == 0);
    
    if isempty(real_roots)
        Z = 1; % Fallback to ideal gas if no real root is found
    else
        Z = max(real_roots);
    end
end